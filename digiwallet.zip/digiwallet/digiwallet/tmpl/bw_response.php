<?php
defined ('_JEXEC') or die();

/**
 * Activates iDEAL, Bancontact, Sofort Banking, Visa / Mastercard Credit cards, PaysafeCard, AfterPay, BankWire, PayPal and Refunds in VirtueMart
 * @author DigiWallet.nl <techsupport@targetmedia.nl>
 * @url https://www.digiwallet.nl
 * @copyright Copyright (C) 2018 - 2020 e-plugins.nl
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
*/

?>
<?php 
list($trxid, $accountNumber, $iban, $bic, $beneficiary, $bank) = explode("|", $viewData['more']);
$currentLanguage = JFactory::getLanguage();
$isNL = $currentLanguage->getTag() == "nl-NL";
$line1 = 'You will receive your order as soon as we receive payment from the bank.<br>Would you be so friendly to transfer the total amount of &euro; %g to the bank account <b style="color:#c30000">%s</b> in name of %s* ?';
$line2 = 'State the payment feature <b>%s</b>, this way the payment can be automatically processed.<br>As soon as this happens you shall receive a confirmation mail on %s.';
$line3 = 'If it is necessary for payments abroad, then the BIC code from the bank <span style="color:#c30000">%s</span> and the name of the bank is %s.';
$line4 = '*Payment for our webstore is processed by TargetMedia. TargetMedia is certified as a Collecting Payment Service Provider by Currence. This means we set the highest security standards when is comes to security of payment for you as a customer and us as a webshop.';
if($isNL) {
    $line1 = 'U ontvangt uw bestelling zodra we de betaling per bank ontvangen hebben.<br>Zou u zo vriendelijk willen zijn het totaalbedrag van &euro; %g over te maken op bankrekening <b style="color:#c30000">%s</b> t.n.v. %s* ?';
    $line2 = 'Vermeld daarbij het betaalkenmerk <b>%s</b> in de omschrijving, zodat de betaling automatisch verwerkt kan worden. Zodra dit gebeurd is ontvangt u een mail op %s ter bevestiging.';
    $line3 = 'Mocht het nodig zijn voor betalingen vanuit het buitenland, dan is de BIC code van de bank <span style="color:#c30000">%s</span> en de naam van de bank is \'%s\'. Zorg ervoor dat u kiest voor kosten in het buitenland voor eigen rekening (optie: OUR), anders zal het bedrag wat binnenkomt te laag zijn.';
    $line4 = '*De betalingen voor onze webwinkel worden verwerkt door TargetMedia. TargetMedia is gecertificeerd als Collecting Payment Service Provider door Currence. Dat houdt in dat zij aan strenge eisen dient te voldoen als het gaat om de veiligheid van de betalingen voor jou als klant en ons als webwinkel.';
}
?>
<div class="bankwire-info">
    <p><?= JText::sprintf($line1, $viewData['total'], $iban, $beneficiary)?></p>
    <p><?= JText::sprintf($line2,$trxid, $viewData['billing_email'])?></p>
    <p><?= JText::sprintf($line3,$bic, $bank)?></p>
    <p><i><?= JText::_($line4)?></i></p>
</div>
<a class="vm-button-correct" href="<?php echo JRoute::_('index.php?option=com_virtuemart&view=orders&layout=details&order_number='.$viewData["order_number"].'&order_pass='.$viewData["order_pass"], false)?>"><?php echo vmText::_('COM_VIRTUEMART_ORDER_VIEW_ORDER'); ?></a>
